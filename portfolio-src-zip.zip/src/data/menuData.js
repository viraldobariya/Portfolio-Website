export let menus = [
    {
        name : "Home",
        href : "/"
    },
    {
        name : "About",
        href : "/about"
    },
    {
        name : "Portfolio",
        href : "/portfolio"
    },
    {
        name : "contact",
        href : "/contact"
    }
]